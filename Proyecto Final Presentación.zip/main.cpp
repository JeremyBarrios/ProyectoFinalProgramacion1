#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cmath>
#include <fstream>
#include <string>

using namespace std;

const int SCREEN_WIDTH = 40;
const int SCREEN_HEIGHT = 20;

char screen[SCREEN_HEIGHT][SCREEN_WIDTH];
int cursorX = SCREEN_WIDTH / 2;
int cursorY = SCREEN_HEIGHT / 2;
char drawChar = '+';
int color = 7;

void setColor(int colorCode) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorCode);
}

void drawOptions() {
    cout << "M: Para abrir menu | ";
    cout << "T: Triangulo | ";
    cout << "Q: Cuadrado | ";
    cout << "R: Rectangulo | ";
    cout << "C: Circulo | ";
    cout << "L: Linea | ";
    cout << "O: Rombo | ";
    cout << "H: Hexagono | ";
    cout << "N: Nuevo Caracter | ";
    cout << "P: Limpiar Pantalla | ";
    cout << "K: Color de Caracter | ";
    cout << "G: Grabar Pantalla | ";
    cout << "A: Abrir Archivo | ";
    cout << "ESC: Salir" << endl;
}

void drawScreen() {
    system("cls");
    drawOptions();
    setColor(color);
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            if (y == cursorY && x == cursorX) {
                cout << '*';
            } else {
                cout << screen[y][x];
            }
        }
        cout << endl;
    }
    setColor(7);
}

void moveCursor(int dx, int dy) {
    int newX = cursorX + dx;
    int newY = cursorY + dy;
    if (newX < 0) newX = SCREEN_WIDTH - 1;
    if (newX >= SCREEN_WIDTH) newX = 0;
    if (newY < 0) newY = SCREEN_HEIGHT - 1;
    if (newY >= SCREEN_HEIGHT) newY = 0;
    cursorX = newX;
    cursorY = newY;
}

void drawSquare() {
    int size;
    char orientation;
    cout << "Ingrese el tamano del cuadrado: ";
    cin >> size;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (size <= 0 || size > SCREEN_WIDTH || size > SCREEN_HEIGHT) {
        cout << "Tamano invalido!" << endl;
        return;
    }
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            switch (orientation) {
                case 'w': screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 's': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'd': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'a': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            }
        }
    }
}

void drawRectangle() {
    int width, height;
    cout << "Ingrese el ancho del rectangulo: ";
    cin >> width;
    cout << "Ingrese el alto del rectangulo: ";
    cin >> height;
    if (width <= 0 || width > SCREEN_WIDTH || height <= 0 || height > SCREEN_HEIGHT) {
        cout << "Dimensiones invalidas!" << endl;
        return;
    }
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
        }
    }
}

void drawCircle() {
    int radius;
    cout << "Ingrese el radio del circulo: ";
    cin >> radius;
    if (radius <= 0 || radius > SCREEN_WIDTH / 2 || radius > SCREEN_HEIGHT / 2) {
        cout << "Radio invalido!" << endl;
        return;
    }
    int centerX = cursorX;
    int centerY = cursorY;

    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            double distance = sqrt(pow(x, 2) + pow(y, 2));
            if (distance <= radius) {
                screen[(centerY + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(centerX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
        }
    }
}

void drawTriangle() {
    int base;
    char orientation;
    cout << "Ingrese la base del triangulo: ";
    cin >> base;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (base <= 0 || base > SCREEN_WIDTH || base > SCREEN_HEIGHT) {
        cout << "Base invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'w':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 's':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'd':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'a':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawLine() {
    int length;
    char orientation;
    cout << "Ingrese la longitud de la linea: ";
    cin >> length;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda, e=Diagonal Derecha Abajo, q=Diagonal Izquierda Arriba, z=Diagonal Izquierda Abajo, c=Diagonal Derecha Arriba): ";
    cin >> orientation;
    if (length <= 0 || length > SCREEN_WIDTH || length > SCREEN_HEIGHT) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    for (int i = 0; i < length; i++) {
        switch (orientation) {
            case 'w': screen[(cursorY - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][cursorX] = drawChar; break;
            case 's': screen[(cursorY + i) % SCREEN_HEIGHT][cursorX] = drawChar; break;
            case 'd': screen[cursorY][(cursorX + i) % SCREEN_WIDTH] = drawChar; break;
            case 'a': screen[cursorY][(cursorX - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            case 'e': screen[(cursorY + i) % SCREEN_HEIGHT][(cursorX + i) % SCREEN_WIDTH] = drawChar; break;
            case 'q': screen[(cursorY - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            case 'z': screen[(cursorY + i) % SCREEN_HEIGHT][(cursorX - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            case 'c': screen[(cursorY - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + i) % SCREEN_WIDTH] = drawChar; break;
            default: cout << "Orientacion invalida!" << endl; return;
        }
    }
}

void drawRhombus() {
    int length;
    char orientation;
    cout << "Ingrese la longitud del lado del rombo: ";
    cin >> length;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo): ";
    cin >> orientation;
    if (length <= 0 || length > SCREEN_WIDTH / 2 || length > SCREEN_HEIGHT / 2) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    int cx = cursorX, cy = cursorY;
    switch (orientation) {
        case 'w':
            for (int i = 0; i <= length; i++) {
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 's':
            for (int i = 0; i <= length; i++) {
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawHexagon() {
    int length;
    char orientation;
    cout << "Ingrese la longitud del lado del hexagono: ";
    cin >> length;
    cout << "Ingrese la orientacion (w=Vertical, d=Horizontal): ";
    cin >> orientation;
    if (length <= 0 || length > SCREEN_WIDTH / 2 || length > SCREEN_HEIGHT / 2) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    int cx = cursorX, cy = cursorY;
    switch (orientation) {
        case 'w':
            for (int i = 0; i < length; i++) {
                screen[(cy - length + i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - length + i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + length - i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + length - i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            for (int i = -length; i <= length; i++) {
                screen[(cy + i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - length + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + length) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'd':
            for (int i = 0; i < length; i++) {
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - length + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + length - i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx - length + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + length - i) % SCREEN_WIDTH] = drawChar;
            }
            for (int i = -length; i <= length; i++) {
                screen[(cy - length + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + length) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void clearScreen() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }
}

void changeDrawChar() {
    cout << "Ingrese el nuevo caracter de dibujo: ";
    cin >> drawChar;
}

void changeColor() {
    cout << "Ingrese el codigo del nuevo color (0-15): ";
    cin >> color;
    if (color < 0 || color > 15) {
        cout << "Codigo de color invalido!" << endl;
        color = 7;
    }
}

void saveScreen() {
    string fileName;
    cout << "Ingrese el nombre del archivo para guardar la pantalla: ";
    cin >> fileName;
    ofstream outFile(fileName);
    if (outFile.is_open()) {
        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            for (int x = 0; x < SCREEN_WIDTH; x++) {
                outFile << screen[y][x];
            }
            outFile << endl;
        }
        outFile.close();
        cout << "Pantalla guardada en " << fileName << endl;
    } else {
        cout << "No se pudo abrir el archivo!" << endl;
    }
}

void openScreen() {
    string fileName;
    cout << "Ingrese el nombre del archivo para abrir: ";
    cin >> fileName;
    ifstream inFile(fileName);
    if (inFile.is_open()) {
        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            for (int x = 0; x < SCREEN_WIDTH; x++) {
                if (inFile.get(screen[y][x])) {
                    if (screen[y][x] == '\n') {
                        x--;
                    }
                } else {
                    screen[y][x] = ' ';
                }
            }
        }
        inFile.close();
        cout << "Pantalla cargada desde " << fileName << endl;
    } else {
        cout << "No se pudo abrir el archivo!" << endl;
    }
}

int main() {
    clearScreen();
    drawScreen();

    while (true) {
        if (_kbhit()) {
            char key = _getch();
            switch (key) {
                case 'm':
                    // Open menu mode is now handled by key presses directly
                    break;
                case 'w':
                    moveCursor(0, -1);
                    break;
                case 's':
                    moveCursor(0, 1);
                    break;
                case 'a':
                    moveCursor(-1, 0);
                    break;
                case 'd':
                    moveCursor(1, 0);
                    break;
                case 't':
                    drawTriangle();
                    break;
                case 'q':
                    drawSquare();
                    break;
                case 'r':
                    drawRectangle();
                    break;
                case 'c':
                    drawCircle();
                    break;
                case 'l':
                    drawLine();
                    break;
                case 'o':
                    drawRhombus();
                    break;
                case 'h':
                    drawHexagon();
                    break;
                case 'n':
                    changeDrawChar();
                    break;
                case 'p':
                    clearScreen();
                    break;
                case 'k':
                    changeColor();
                    break;
                case 'g':
                    saveScreen();
                    break;
                case 'A': // changed the key for opening file to 'A'
                    openScreen();
                    break;
                case 27: // ESC key
                    return 0;
                default:
                    break;
            }
            drawScreen();
        }
    }

    return 0;
}
