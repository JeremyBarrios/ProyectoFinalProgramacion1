#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cmath>

using namespace std;

const int SCREEN_WIDTH = 40;
const int SCREEN_HEIGHT = 20;

char screen[SCREEN_HEIGHT][SCREEN_WIDTH];
int cursorX = SCREEN_WIDTH / 2;
int cursorY = SCREEN_HEIGHT / 2;

void drawScreen() {
    system("cls");
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            if (y == cursorY && x == cursorX) {
                cout << '*';
            } else {
                cout << screen[y][x];
            }
        }
        cout << endl;
    }
}

void moveCursor(int dx, int dy) {
    int newX = cursorX + dx;
    int newY = cursorY + dy;
    if (newX < 0) newX = SCREEN_WIDTH - 1;
    if (newX >= SCREEN_WIDTH) newX = 0;
    if (newY < 0) newY = SCREEN_HEIGHT - 1;
    if (newY >= SCREEN_HEIGHT) newY = 0;
    cursorX = newX;
    cursorY = newY;
}

void drawSquare() {
    int size;
    cout << "Ingrese el tamano del cuadrado: ";
    cin >> size;
    for (int y = cursorY; y < cursorY + size; y++) {
        screen[y % SCREEN_HEIGHT][cursorX] = '+';
        screen[y % SCREEN_HEIGHT][(cursorX + size - 1) % SCREEN_WIDTH] = '+';
    }
    for (int x = cursorX + 1; x < cursorX + size - 1; x++) {
        screen[cursorY][x % SCREEN_WIDTH] = '+';
        screen[(cursorY + size - 1) % SCREEN_HEIGHT][x % SCREEN_WIDTH] = '+';
    }
}

void drawCircle() {
    int radius;
    cout << "Ingrese el radio del circulo: ";
    cin >> radius;
    int centerX = cursorX + radius;
    int centerY = cursorY + radius;

    for (int y = cursorY; y < cursorY + radius * 2; y++) {
        for (int x = cursorX; x < cursorX + radius * 2; x++) {
            double distance = sqrt(pow(x - centerX, 2) + pow(y - centerY, 2));
            if (distance <= radius) {
                screen[y % SCREEN_HEIGHT][x % SCREEN_WIDTH] = '+';
            }
        }
    }
}

void drawTriangle() {
    int base;
    cout << "Ingrese la base del triangulo: ";
    cin >> base;
    screen[cursorY][cursorX + base / 2] = '+';
    screen[cursorY + base / 2][cursorX] = '+';
    screen[cursorY + base / 2][cursorX + base - 1] = '+';
}

void clearScreen() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }
}

int main() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }

    drawScreen();

    bool menuMode = false;

    while (true) {
        if (menuMode) {
            cout << "Seleccione una figura:" << endl;
            cout << "1. Cuadrado" << endl;
            cout << "2. Circulo" << endl;
            cout << "3. Triangulo" << endl;
            cout << "4. Borrar todo" << endl;
            cout << "Q. Salir" << endl;

            char key = _getch();
            switch (key) {
                case '1':
                    drawSquare();
                    break;
                case '2':
                    drawCircle();
                    break;
                case '3':
                    drawTriangle();
                    break;
                case '4':
                    clearScreen();
                    break;
                case 'q':
                    return 0;
                default:
                    break;
            }

            menuMode = false;
            drawScreen();
        } else {
            if (_kbhit()) {
                char key = _getch();
                switch (key) {
                    case 'm':
                        menuMode = true;
                        break;
                    case 'w':
                        moveCursor(0, -1);
                        break;
                    case 's':
                        moveCursor(0, 1);
                        break;
                    case 'a':
                        moveCursor(-1, 0);
                        break;
                    case 'd':
                        moveCursor(1, 0);
                        break;
                    case 'q':
                        return 0;
                    default:
                        break;
                }
                drawScreen();
            }
        }
    }

    return 0;
}
