#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cmath>

using namespace std;

const int SCREEN_WIDTH = 40;
const int SCREEN_HEIGHT = 20;

char screen[SCREEN_HEIGHT][SCREEN_WIDTH];
int cursorX = SCREEN_WIDTH / 2;
int cursorY = SCREEN_HEIGHT / 2;
char drawChar = '+';
int color = 7;  // Default color: white

void setColor(int colorCode) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorCode);
}

void drawScreen() {
    system("cls");
    setColor(color);
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            if (y == cursorY && x == cursorX) {
                cout << '*';
            } else {
                cout << screen[y][x];
            }
        }
        cout << endl;
    }
    setColor(7);  // Reset to default color
}

void moveCursor(int dx, int dy) {
    int newX = cursorX + dx;
    int newY = cursorY + dy;
    if (newX < 0) newX = SCREEN_WIDTH - 1;
    if (newX >= SCREEN_WIDTH) newX = 0;
    if (newY < 0) newY = SCREEN_HEIGHT - 1;
    if (newY >= SCREEN_HEIGHT) newY = 0;
    cursorX = newX;
    cursorY = newY;
}

void drawSquare() {
    int size;
    char orientation;
    cout << "Ingrese el tamano del cuadrado: ";
    cin >> size;
    cout << "Ingrese la orientacion (a=Arriba, b=Abajo, d=Derecha, i=Izquierda): ";
    cin >> orientation;
    if (size <= 0 || size > SCREEN_WIDTH || size > SCREEN_HEIGHT) {
        cout << "Tamano invalido!" << endl;
        return;
    }
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            switch (orientation) {
                case 'a': screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'b': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'd': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'i': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            }
        }
    }
}

void drawCircle() {
    int radius;
    cout << "Ingrese el radio del circulo: ";
    cin >> radius;
    if (radius <= 0 || radius > SCREEN_WIDTH / 2 || radius > SCREEN_HEIGHT / 2) {
        cout << "Radio invalido!" << endl;
        return;
    }
    int centerX = cursorX;
    int centerY = cursorY;

    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            double distance = sqrt(pow(x, 2) + pow(y, 2));
            if (distance <= radius) {
                screen[(centerY + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(centerX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
        }
    }
}

void drawTriangle() {
    int base;
    char orientation;
    cout << "Ingrese la base del triangulo: ";
    cin >> base;
    cout << "Ingrese la orientacion (a=Arriba, b=Abajo, d=Derecha, i=Izquierda): ";
    cin >> orientation;
    if (base <= 0 || base > SCREEN_WIDTH || base > SCREEN_HEIGHT) {
        cout << "Base invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'a':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'b':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'd':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'i':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawLine() {
    int length;
    char orientation;
    cout << "Ingrese la longitud de la linea: ";
    cin >> length;
    cout << "Ingrese la orientacion (a=Arriba, b=Abajo, d=Derecha, i=Izquierda, q=Diagonal Derecha Arriba, e=Diagonal Derecha Abajo, z=Diagonal Izquierda Arriba, c=Diagonal Izquierda Abajo): ";
    cin >> orientation;
    if (length <= 0 || length > SCREEN_WIDTH || length > SCREEN_HEIGHT) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'a':
            for (int y = 0; y < length; y++) {
                screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][cursorX] = drawChar;
            }
            break;
        case 'b':
            for (int y = 0; y < length; y++) {
                screen[(cursorY + y) % SCREEN_HEIGHT][cursorX] = drawChar;
            }
            break;
        case 'd':
            for (int x = 0; x < length; x++) {
                screen[cursorY][(cursorX + x) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'i':
            for (int x = 0; x < length; x++) {
                screen[cursorY][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'q':
            for (int i = 0; i < length; i++) {
                screen[(cursorY - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'e':
            for (int i = 0; i < length; i++) {
                screen[(cursorY + i) % SCREEN_HEIGHT][(cursorX + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'z':
            for (int i = 0; i < length; i++) {
                screen[(cursorY - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'c':
            for (int i = 0; i < length; i++) {
                screen[(cursorY + i) % SCREEN_HEIGHT][(cursorX - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawRhombus() {
    int sideLength;
    char orientation;
    cout << "Ingrese la longitud del lado del rombo: ";
    cin >> sideLength;
    cout << "Ingrese la orientacion (a=Arriba, b=Abajo): ";
    cin >> orientation;
    if (sideLength <= 0 || sideLength > SCREEN_WIDTH || sideLength > SCREEN_HEIGHT) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'a':
            for (int y = 0; y < sideLength; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            for (int y = sideLength - 2; y >= 0; y--) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - (sideLength - 1) + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'b':
            for (int y = 0; y < sideLength; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            for (int y = sideLength - 2; y >= 0; y--) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY + (sideLength - 1) - y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawHexagon() {
    int sideLength;
    char orientation;
    cout << "Ingrese la longitud del lado del hexagono: ";
    cin >> sideLength;
    cout << "Ingrese la orientacion (v=Vertical, h=Horizontal): ";
    cin >> orientation;
    if (sideLength <= 0 || sideLength > SCREEN_WIDTH / 2 || sideLength > SCREEN_HEIGHT / 2) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'v':
            for (int y = 0; y < sideLength; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            for (int y = sideLength; y < 2 * sideLength; y++) {
                for (int x = -(2 * sideLength - y); x <= (2 * sideLength - y); x++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'h':
            for (int x = 0; x < sideLength; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            for (int x = sideLength; x < 2 * sideLength; x++) {
                for (int y = -(2 * sideLength - x); y <= (2 * sideLength - x); y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void clearScreen() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }
}

void changeDrawChar() {
    cout << "Ingrese el caracter para dibujar: ";
    cin >> drawChar;
}

void changeColor() {
    cout << "Ingrese el codigo del color (0-15): ";
    cin >> color;
    if (color < 0 || color > 15) {
        cout << "Codigo de color invalido!" << endl;
        color = 7;  // Reset to default color if invalid
    }
}

int main() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }

    drawScreen();

    bool menuMode = false;

    while (true) {
        if (menuMode) {
            cout << "Seleccione una figura:" << endl;
            cout << "1. Cuadrado" << endl;
            cout << "2. Circulo" << endl;
            cout << "3. Triangulo" << endl;
            cout << "4. Linea" << endl;
            cout << "5. Rombo" << endl;
            cout << "6. Hexagono" << endl;
            cout << "7. Cambiar caracter de dibujo" << endl;
            cout << "8. Cambiar color" << endl;
            cout << "0. Borrar todo" << endl;
            cout << "Q. Salir" << endl;

            char key = _getch();
            switch (key) {
                case '1':
                    drawSquare();
                    break;
                case '2':
                    drawCircle();
                    break;
                case '3':
                    drawTriangle();
                    break;
                case '4':
                    drawLine();
                    break;
                case '5':
                    drawRhombus();
                    break;
                case '6':
                    drawHexagon();
                    break;
                case '7':
                    changeDrawChar();
                    break;
                case '8':
                    changeColor();
                    break;
                case '0':
                    clearScreen();
                    break;
                case 'q':
                case 'Q':
                    return 0;
                default:
                    break;
            }

            menuMode = false;
            drawScreen();
        } else {
            if (_kbhit()) {
                char key = _getch();
                switch (key) {
                    case 'm':
                        menuMode = true;
                        break;
                    case 'w':
                        moveCursor(0, -1);
                        break;
                    case 's':
                        moveCursor(0, 1);
                        break;
                    case 'a':
                        moveCursor(-1, 0);
                        break;
                    case 'd':
                        moveCursor(1, 0);
                        break;
                    case 'q':
                    case 'Q':
                        return 0;
                    default:
                        break;
                }
                drawScreen();
            }
        }
    }

    return 0;
}
