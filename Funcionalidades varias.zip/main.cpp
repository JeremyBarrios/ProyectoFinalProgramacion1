#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cmath>

using namespace std;

const int SCREEN_WIDTH = 40;
const int SCREEN_HEIGHT = 20;

char screen[SCREEN_HEIGHT][SCREEN_WIDTH];
int cursorX = SCREEN_WIDTH / 2;
int cursorY = SCREEN_HEIGHT / 2;
char drawChar = '+';
int color = 7;

void setColor(int colorCode) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorCode);
}

void drawOptions() {
    cout << "M: Para abrir menu | ";
    cout << "T: Triangulo | ";
    cout << "Q: Cuadrado | ";
    cout << "R: Rectangulo | ";
    cout << "C: Circulo | ";
    cout << "L: Linea | ";
    cout << "O: Rombo | ";
    cout << "H: Hexagono | ";
    cout << "N: Nuevo Caracter | ";
    cout << "P: Limpiar Pantalla | ";
    cout << "K: Color de Caracter | ";
    cout << "ESC: Salir" << endl;
}

void drawScreen() {
    system("cls");
    drawOptions();
    setColor(color);
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            if (y == cursorY && x == cursorX) {
                cout << '*';
            } else {
                cout << screen[y][x];
            }
        }
        cout << endl;
    }
    setColor(7);
}

void moveCursor(int dx, int dy) {
    int newX = cursorX + dx;
    int newY = cursorY + dy;
    if (newX < 0) newX = SCREEN_WIDTH - 1;
    if (newX >= SCREEN_WIDTH) newX = 0;
    if (newY < 0) newY = SCREEN_HEIGHT - 1;
    if (newY >= SCREEN_HEIGHT) newY = 0;
    cursorX = newX;
    cursorY = newY;
}

void drawSquare() {
    int size;
    char orientation;
    cout << "Ingrese el tamano del cuadrado: ";
    cin >> size;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (size <= 0 || size > SCREEN_WIDTH || size > SCREEN_HEIGHT) {
        cout << "Tamano invalido!" << endl;
        return;
    }
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            switch (orientation) {
                case 'w': screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 's': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'd': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'a': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            }
        }
    }
}

void drawCircle() {
    int radius;
    cout << "Ingrese el radio del circulo: ";
    cin >> radius;
    if (radius <= 0 || radius > SCREEN_WIDTH / 2 || radius > SCREEN_HEIGHT / 2) {
        cout << "Radio invalido!" << endl;
        return;
    }
    int centerX = cursorX;
    int centerY = cursorY;

    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            double distance = sqrt(pow(x, 2) + pow(y, 2));
            if (distance <= radius) {
                screen[(centerY + y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(centerX + x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
        }
    }
}

void drawTriangle() {
    int base;
    char orientation;
    cout << "Ingrese la base del triangulo: ";
    cin >> base;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (base <= 0 || base > SCREEN_WIDTH || base > SCREEN_HEIGHT) {
        cout << "Base invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'w':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 's':
            for (int y = 0; y <= base / 2; y++) {
                for (int x = -y; x <= y; x++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'd':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        case 'a':
            for (int x = 0; x <= base / 2; x++) {
                for (int y = -x; y <= x; y++) {
                    screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                }
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawLine() {
    int length;
    char orientation;
    cout << "Ingrese la longitud de la linea: ";
    cin >> length;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (length <= 0 || length > SCREEN_WIDTH || length > SCREEN_HEIGHT) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    switch (orientation) {
        case 'w':
            for (int y = 0; y < length; y++) {
                screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][cursorX] = drawChar;
            }
            break;
        case 's':
            for (int y = 0; y < length; y++) {
                screen[(cursorY + y) % SCREEN_HEIGHT][cursorX] = drawChar;
            }
            break;
        case 'd':
            for (int x = 0; x < length; x++) {
                screen[cursorY][(cursorX + x) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'a':
            for (int x = 0; x < length; x++) {
                screen[cursorY][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawRhombus() {
    int sideLength;
    char orientation;
    cout << "Ingrese la longitud del lado del rombo: ";
    cin >> sideLength;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo): ";
    cin >> orientation;
    if (sideLength <= 0 || sideLength > SCREEN_WIDTH / 2 || sideLength > SCREEN_HEIGHT / 2) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    int cx = cursorX, cy = cursorY;
    switch (orientation) {
        case 'w':
            for (int i = 0; i <= sideLength; i++) {
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 's':
            for (int i = 0; i <= sideLength; i++) {
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawHexagon() {
    int sideLength;
    char orientation;
    cout << "Ingrese la longitud del lado del hexagono: ";
    cin >> sideLength;
    cout << "Ingrese la orientacion (v=Vertical, h=Horizontal): ";
    cin >> orientation;
    if (sideLength <= 0 || sideLength > SCREEN_WIDTH / 2 || sideLength > SCREEN_HEIGHT / 2) {
        cout << "Longitud invalida!" << endl;
        return;
    }
    int cx = cursorX, cy = cursorY;
    switch (orientation) {
        case 'v':
            for (int i = 0; i <= sideLength; i++) {
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            for (int i = -sideLength; i <= sideLength; i++) {
                screen[(cy - sideLength + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + sideLength) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        case 'h':
            for (int i = 0; i <= sideLength; i++) {
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy - i + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx - i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + i) % SCREEN_HEIGHT][(cx + i) % SCREEN_WIDTH] = drawChar;
            }
            for (int i = -sideLength; i <= sideLength; i++) {
                screen[(cy - sideLength + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
                screen[(cy + sideLength) % SCREEN_HEIGHT][(cx + i + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar;
            }
            break;
        default:
            cout << "Orientacion invalida!" << endl;
            break;
    }
}

void drawRect() {
    int width, height;
    char orientation;
    cout << "Ingrese el ancho del rectangulo: ";
    cin >> width;
    cout << "Ingrese la altura del rectangulo: ";
    cin >> height;
    cout << "Ingrese la orientacion (w=Arriba, s=Abajo, d=Derecha, a=Izquierda): ";
    cin >> orientation;
    if (width <= 0 || width > SCREEN_WIDTH || height <= 0 || height > SCREEN_HEIGHT) {
        cout << "Dimensiones invalidas!" << endl;
        return;
    }
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            switch (orientation) {
                case 'w': screen[(cursorY - y + SCREEN_HEIGHT) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 's': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'd': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX + x) % SCREEN_WIDTH] = drawChar; break;
                case 'a': screen[(cursorY + y) % SCREEN_HEIGHT][(cursorX - x + SCREEN_WIDTH) % SCREEN_WIDTH] = drawChar; break;
            }
        }
    }
}

void setCharacter() {
    cout << "Ingrese el nuevo caracter para dibujar: ";
    cin >> drawChar;
}

void setColor() {
    cout << "Ingrese el nuevo color (0-15): ";
    cin >> color;
    if (color < 0 || color > 15) {
        cout << "Color invalido!" << endl;
        color = 7;
    }
}

void clearScreen() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            screen[y][x] = ' ';
        }
    }
}

int main() {
    char input;
    clearScreen();
    while (true) {
        drawScreen();
        input = _getch();
        if (input == 27) {
            break;
        } else if (input == 'w') {
            moveCursor(0, -1);
        } else if (input == 'a') {
            moveCursor(-1, 0);
        } else if (input == 's') {
            moveCursor(0, 1);
        } else if (input == 'd') {
            moveCursor(1, 0);
        } else if (input == 'T' || input == 't') {
            drawTriangle();
        } else if (input == 'Q' || input == 'q') {
            drawSquare();
        } else if (input == 'R' || input == 'r') {
            drawRect();
        } else if (input == 'C' || input == 'c') {
            drawCircle();
        } else if (input == 'L' || input == 'l') {
            drawLine();
        } else if (input == 'O' || input == 'o') {
            drawRhombus();
        } else if (input == 'H' || input == 'h') {
            drawHexagon();
        } else if (input == 'N' || input == 'n') {
            setCharacter();
        } else if (input == 'P' || input == 'p') {
            clearScreen();
        } else if (input == 'K' || input == 'k') {
            setColor();
        }
    }
    return 0;
}
